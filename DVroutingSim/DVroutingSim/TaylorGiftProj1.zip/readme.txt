Taylor Gift
11.6.2015
readme

!!! MAKE SURE TOPOLOGY FILE HAS AT MOST 1 NEWLINE CHARACTER AT THE END !!!
!!! SEGMENTATION FAULT WILL OCCUR IF MORE THAN 1 NEWLINE CHARACTER IS PRESENT !!!

Command line compilation: make
Command line execution: ./a topology1.txt 20